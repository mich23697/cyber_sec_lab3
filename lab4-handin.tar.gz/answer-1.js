var allCookies = document.cookie;
alert(allCookies);